#!/usr/bin/python

import math

def function(x) :
	if x <= 1 :
		return x
	else :
		return (function(x-1)+function(x-2))

def encrypt(string) :
	key = [104, 116, 116, 112, 115, 58, 47, 47, 119, 119, 119, 46, 121, 111, 117, 116, 117, 98, 101, 46, 99, 111, 109, 47, 119, 97, 116, 99, 104, 63, 118, 61, 100, 81, 119, 52, 119, 57, 87, 103, 88, 99, 81]
	if len(string)>len(key):
		print "text is too big"		
		return	
	result  =  0
	for i in range(len(string)) :
		magic = int(round(math.exp(math.log(ord(string[i]))+math.log(function[i+20]))))
		magic = ((magic | key[i]) & (~magic | ~key[i]))
		result=(result*10)+len(str(magic))
		hooli = magic
		while(hooli > 0):
			hooli = hooli//10
			result = result * 10
		result = result + magic	
	f = open("out.txt", "w")
	f.write(str(result))
	f.close()

"""
def decrypt(string) : 
	key = [104, 116, 116, 112, 115, 58, 47, 47, 119, 119, 119, 46, 121, 111, 117, 116, 117, 98, 101, 46, 99, 111, 109, 47, 119, 97, 116, 99, 104, 63, 118, 61, 100, 81, 119, 52, 119, 57, 87, 103, 88, 99, 81]
	tab=[]
	if len(string) < len(key):
		for i in range(len(string),len(key)):
			string=string+"*"
	for i in range(len(key)) :
		l = ord(string[i]) ^ ord(string[i])
		j = key[i]+l
		tab.append(j)
	result=""
	for i in tab :
		result=result+chr(i).rstrip()
	print result
#decrypt(raw_input("enter text to decrypt : \n"))
"""
encrypt(raw_input("enter a text to encrypt : \n"))
